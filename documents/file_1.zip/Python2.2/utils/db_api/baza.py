import sqlite3


class Database:
    def __init__(self, path_to_db="main.db"):
        self.path_to_db = path_to_db

    @property
    def connection(self):
        return sqlite3.connect(self.path_to_db)

    def execute(self, sql: str, parameters: tuple = None, fetchone=False, fetchall=False, commit=False):
        if not parameters:
            parameters = ()
        connection = self.connection
        connection.set_trace_callback(logger)
        cursor = connection.cursor()
        data = None
        cursor.execute(sql, parameters)

        if commit:
            connection.commit()
        if fetchall:
            data = cursor.fetchall()
        if fetchone:
            data = cursor.fetchone()
        connection.close()
        return data

    def create_table_users(self):
        sql = """
        CREATE TABLE myfiles_menu (
            id int NOT NULL,
            Name varchar(255) NOT NULL,
            email varchar(255),
            language varchar(3),
            PRIMARY KEY (id)
            );
"""
        self.execute(sql, commit=True)

    @staticmethod
    def format_args(sql, parameters: dict):
        sql += " AND ".join([
            f"{item} = ?" for item in parameters
        ])
        return sql, tuple(parameters.values())

    def add_user(self, id: int, name: str, email: str = None, language: str = 'uz'):
        # SQL_EXAMPLE = "INSERT INTO myfiles_menu(id, Name, email) VALUES(1, 'John', 'John@gmail.com')"

        sql = """
        INSERT INTO myfiles_menu(id, Name, email, language) VALUES(?, ?, ?, ?)
        """
        self.execute(sql, parameters=(id, name, email, language), commit=True)

    def select_all_users_tg_id(self):
        sql = """
        SELECT mijoz_id FROM Myfiles_anketa
        """
        return self.execute(sql, fetchall=True)

    def select_user(self, **kwargs):
        # SQL_EXAMPLE = "SELECT * FROM myfiles_menu where id=1 AND Name='John'"
        sql = "SELECT * FROM Myfiles_type WHERE "
        sql, parameters = self.format_args(sql, kwargs)

        return self.execute(sql, parameters=parameters, fetchone=True)

    def filter_product(self, **kwargs):
        # SQL_EXAMPLE = "SELECT * FROM myfiles_menu where id=1 AND Name='John'"
        sql = "SELECT * FROM  Myfiles_product WHERE "
        sql, parameters = self.format_args(sql, kwargs)

        return self.execute(sql, parameters=parameters, fetchall=True)
    def count_users(self):
        return self.execute("SELECT COUNT(*) FROM auth_user;", fetchone=True)

    def update_user_email(self, email, id):
        # SQL_EXAMPLE = "UPDATE myfiles_menu SET email=mail@gmail.com WHERE id=12345"

        sql = f"""
        UPDATE myfiles_menu SET email=? WHERE id=?
        """
        return self.execute(sql, parameters=(email, id), commit=True)

    def delete_users(self):
        self.execute("DELETE FROM myfiles_menu WHERE TRUE", commit=True)

    def anketa(self, ism: str, fam: str ,yosh:str, tel:str, jins:str, shaxar:str, username:str,mijoz_id=int):
        # SQL_EXAMPLE = "INSERT INTO Myfiles_Anketa(id, Name, email) VALUES(1, 'John', 'John@gmail.com')"

        sql = """
        INSERT INTO  Myfiles_anketa (ism, fam, yosh, tel, jins ,shaxar, username,mijoz_id) VALUES(?, ?, ?, ?, ?, ?, ?, ?)
        """

        self.execute(sql, parameters=(ism,fam,yosh,tel,jins,shaxar,username,mijoz_id), commit=True)

    def select_product(self, **kwargs):
        # SQL_EXAMPLE = "SELECT * FROM myfiles_menu where id=1 AND Name='John'"
        sql = "SELECT * FROM Myfiles_product WHERE  "
        sql, parameters = self.format_args(sql, kwargs)
        return self.execute(sql, parameters=parameters, fetchone=True)

    def select_all_menu(self):
        sql = """
        SELECT * FROM menu
        """
        return self.execute(sql, fetchall=True)

    def select_maxsulot(self, **kwargs):
        # SQL_EXAMPLE = "SELECT * FROM myfiles_menu where id=1 AND Name='John'"
        sql = "SELECT nomi FROM maxsulotlar WHERE "
        sql, parameters = self.format_args(sql, kwargs)

        return self.execute(sql, parameters=parameters, fetchall=True)

    def select_maxsulot_only(self, **kwargs):
        # SQL_EXAMPLE = "SELECT * FROM myfiles_menu where id=1 AND Name='John'"
        sql = "SELECT * FROM maxsulotlar WHERE "
        sql, parameters = self.format_args(sql, kwargs)

        return self.execute(sql, parameters=parameters, fetchone=True)

    def select_maxsulot_from_korzinka_only(self, **kwargs):
        # SQL_EXAMPLE = "SELECT * FROM myfiles_menu where id=1 AND Name='John'"
        sql = "SELECT * FROM korzinka WHERE "
        sql, parameters = self.format_args(sql, kwargs)

        return self.execute(sql, parameters=parameters, fetchone=True)

    def select_all_maxsulotlar(self):
        sql = """
        SELECT nomi FROM maxsulotlar
        """
        return self.execute(sql, fetchall=True)

    def add_maxsulot_to_korzinka(self, nomi: str, narxi:int, soni:int, rasm:str, tg_id:int, ism:str):
        # SQL_EXAMPLE = "INSERT INTO myfiles_menu(id, Name, email) VALUES(1, 'John', 'John@gmail.com')"

        sql = """
        INSERT INTO korzinka (nomi,narxi,rasm,soni,tg_id,ism) VALUES(?, ?, ?, ?, ?, ?)
        """
        self.execute(sql, parameters=(nomi,narxi,rasm,soni,tg_id,ism), commit=True)



    def count_maxsulot(self, **kwargs):
        # SQL_EXAMPLE = "SELECT * FROM myfiles_menu where id=1 AND Name='John'"
        sql = "SELECT COUNT(*) FROM korzinka WHERE "
        sql, parameters = self.format_args(sql, kwargs)

        return self.execute(sql, parameters=parameters, fetchone=True)

    def update_user_korzinka(self, soni, tg_id,nomi):
        # SQL_EXAMPLE = "UPDATE myfiles_menu SET email=mail@gmail.com WHERE id=12345"

        sql = f"""
        UPDATE korzinka SET soni=? WHERE tg_id=? and nomi=?
        """
        return self.execute(sql, parameters=(soni, tg_id,nomi), commit=True)

    def select_maxsulotlar_from_korzinka(self, **kwargs):
        # SQL_EXAMPLE = "SELECT * FROM myfiles_menu where id=1 AND Name='John'"
        sql = "SELECT * FROM korzinka WHERE "
        sql, parameters = self.format_args(sql, kwargs)

        return self.execute(sql, parameters=parameters, fetchall=True)

    def delet_maxsulot_from_korzinka(self, **kwargs):
        # SQL_EXAMPLE = "SELECT * FROM myfiles_menu where id=1 AND Name='John'"
        sql = "DELETE FROM korzinka WHERE "
        sql, parameters = self.format_args(sql, kwargs)

        return self.execute(sql, parameters=parameters, commit=True)

def logger(statement):
    print(f"""
_____________________________________________________        
Executing: 
{statement}
_____________________________________________________
""")
