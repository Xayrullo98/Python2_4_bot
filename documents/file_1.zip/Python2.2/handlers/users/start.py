from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.builtin import CommandStart
from aiogram.types import KeyboardButton, ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from states.holatlar import Tanlov,Korzinka
from keyboards.default.menu_uchun import menu_buttons,tasdiqlash_buttons
from loader import dp,base,bot


@dp.message_handler(CommandStart())
async def bot_start(message: types.Message):
    await message.answer(f"Salom, {message.from_user.full_name}!",reply_markup=menu_buttons)


menular = base.select_all_menu()

@dp.message_handler(text=[menu[1] for menu in menular])
async def bot_start(message: types.Message):
    menu_nomi = message.text
    tanlangan_menu = base.select_maxsulot(tur=menu_nomi)
    index = 0
    keys = []
    j = 0
    print(tanlangan_menu)
    for menu in tanlangan_menu:

        if j % 2 == 0 and j != 0:
            index += 1
        if j % 2 == 0:
            keys.append([KeyboardButton(text=f'{menu[0]}', )])
        else:
            keys[index].append(KeyboardButton(text=f'{menu[0]}', ))
        j += 1
    keys.append([KeyboardButton(text='Ortga')])
    menu_buttons = ReplyKeyboardMarkup(keyboard=keys, resize_keyboard=True)
    await message.answer(f"Maxsulotni tanlang ",reply_markup=menu_buttons)
    await Tanlov.maxsulot_tanlash_holati.set()

@dp.message_handler(text='Ortga' ,state=Tanlov.maxsulot_tanlash_holati)
async def bot_start(message: types.Message,state:FSMContext):
    await message.answer(f"Salom, {message.from_user.full_name}!",reply_markup=menu_buttons)
    await state.finish()

@dp.message_handler(commands='start' ,state=Tanlov.maxsulot_tanlash_holati)
async def bot_start(message: types.Message,state:FSMContext):
    await message.answer(f"Salom, {message.from_user.full_name}!",reply_markup=menu_buttons)
    await state.finish()

maxsulotlar = base.select_all_maxsulotlar()
@dp.message_handler(text=[maxsulot[0] for maxsulot in maxsulotlar] ,state=Tanlov.maxsulot_tanlash_holati)
async def bot_start(message: types.Message):
    maxsulot_nomi = message.text
    maxsulot = base.select_maxsulot_only(nomi=maxsulot_nomi)
    maxsulot_id= maxsulot[0]
    nomi = maxsulot[1]
    narxi = maxsulot[2]
    rasm_link = maxsulot[3]
    kg = maxsulot[6]
    user_id = message.from_user.id
    await bot.send_photo(chat_id=user_id,photo=rasm_link,caption=f"Nomi : {nomi}\n"
                                                                 f"Narxi : {narxi}\n"
                                                                 f"Kg    : {kg}",
                         reply_markup=InlineKeyboardMarkup(inline_keyboard=
                                                           [[InlineKeyboardButton(text='Sotib olish',callback_data=f'{maxsulot_id}')]]))
    await Tanlov.sotib_olish_holati.set()


@dp.callback_query_handler( state=Tanlov.sotib_olish_holati)
async def bot_start(xabar: CallbackQuery,state:FSMContext):
    maxsulot_id = xabar.data
    user_id = xabar.from_user.id
    """
    (2, 'Lagmon', 15000, 'https://t.me/uzpythonjobs/601', 'Taomlar', None, 1, None)

    """
    maxsulot = base.select_maxsulot_only(id=maxsulot_id)
    maxsulot_nomi = maxsulot[1]
    tekshirish = base.count_maxsulot(tg_id=user_id,nomi=maxsulot_nomi)
    if tekshirish[0] ==0:
        maxsulot_narxi = maxsulot[2]
        maxsulot_rasmi = maxsulot[3]
        maxsulot_soni= 1
        user_id = xabar.from_user.id
        ism = xabar.from_user.first_name
        base.add_maxsulot_to_korzinka(nomi=maxsulot_nomi,narxi=maxsulot_narxi,soni=maxsulot_soni,rasm=maxsulot_rasmi,tg_id=user_id,ism=ism)
    else:
        new_soni = tekshirish[0]+1
        base.update_user_korzinka(soni=new_soni,tg_id=user_id,nomi=maxsulot_nomi)
    await xabar.message.answer(text=f"maxsulot xarid qilindi yana maxsulot tanlang ...{tekshirish}")
    await Tanlov.maxsulot_tanlash_holati.set()





@dp.message_handler(text="Korzinka")
async def bot_start(message: types.Message):
    user_id = message.from_user.id
    products = base.select_maxsulotlar_from_korzinka(tg_id=user_id)

    for maxsulot in products:
        """
        (6, 'Lagmon', 15000, 'https://t.me/uzpythonjobs/601', 3, 5883029982, 'Pythoner')
        """
        maxsulot_id = maxsulot[0]
        nomi = maxsulot[1]
        narxi = maxsulot[2]
        rasm_link = maxsulot[3]
        soni = maxsulot[4]
        user_id = message.from_user.id
        await bot.send_photo(chat_id=user_id, photo=rasm_link, caption=f"Nomi : {nomi}\n"
                                                                       f"Narxi : {narxi}\n"
                                                                       f"Soni    : {soni}",
                             reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                                 [
                                     InlineKeyboardButton(text='+',callback_data=f'add{maxsulot_id}'),
                                     InlineKeyboardButton(text='-',callback_data=f'sub{maxsulot_id}')
                                 ],
                                 [
                                     InlineKeyboardButton(text="O'chirish",callback_data=f'del{maxsulot_id}')
                                 ]
                             ]))
    await bot.send_message(chat_id=user_id,text="Sotib olish uchun tasdiqlash tugamasini tanlang",reply_markup=tasdiqlash_buttons)
    await Korzinka.update_holati.set()

@dp.message_handler(text="Bekor qilish",state=Korzinka.update_holati)
async def bot_start(message: types.Message,state:FSMContext):
    user_id = message.from_user.id
    await bot.send_message(chat_id=user_id,text='Bekor qilindi',reply_markup=menu_buttons)
    base.delet_maxsulot_from_korzinka(tg_id=user_id)
    await state.finish()



@dp.message_handler(text="Tasdiqlash",state=Korzinka.update_holati)
async def bot_start(message: types.Message,state:FSMContext):
    user_id = message.from_user.id
    products = base.select_maxsulotlar_from_korzinka(tg_id=user_id)
    matn = ''
    yigindi = 0
    for maxsulot in products:
        """
        (6, 'Lagmon', 15000, 'https://t.me/uzpythonjobs/601', 3, 5883029982, 'Pythoner')
        """
        maxsulot_id = maxsulot[0]
        nomi = maxsulot[1]
        narxi = maxsulot[2]
        rasm_link = maxsulot[3]
        soni = maxsulot[4]
        user_id = message.from_user.id
        matn+=f" Nomi : {nomi}   Narxi : {narxi}   Soni : {soni}  Umumiy_narxi : {narxi*soni} so'm \n"
        yigindi += narxi*soni
    matn+= f"Umumiy summa : {yigindi} \n"
    await bot.send_message(chat_id=user_id,text=matn,reply_markup=menu_buttons)
    matn+=f"Ism : {message.from_user.first_name}"
    await bot.send_message(chat_id='5883029982',text=matn)
    base.delet_maxsulot_from_korzinka(tg_id=user_id)
    await state.finish()

@dp.callback_query_handler( state=Korzinka.update_holati)
async def bot_start(xabar: CallbackQuery,state:FSMContext):
    malumot = str(xabar.data)[:3]

    maxsulot_id =str(xabar.data)[3:]
    user_id = xabar.from_user.id
    maxsulot = base.select_maxsulot_from_korzinka_only(id=maxsulot_id)
    maxsulot_nomi = maxsulot[1]
    tekshirish = base.select_maxsulot_from_korzinka_only(tg_id=user_id, nomi=maxsulot_nomi)
    print(tekshirish)
    if malumot=='add':
        new_soni = tekshirish[4] + 1
        base.update_user_korzinka(soni=new_soni, tg_id=user_id, nomi=maxsulot_nomi)
    elif malumot=='sub':
        new_soni = tekshirish[4] - 1
        base.update_user_korzinka(soni=new_soni, tg_id=user_id, nomi=maxsulot_nomi)
    elif malumot=='del':
        base.delet_maxsulot_from_korzinka(tg_id=user_id,nomi=maxsulot_nomi)
    await xabar.message.answer(text=f'{malumot}')
    await Korzinka.update_holati.set()











